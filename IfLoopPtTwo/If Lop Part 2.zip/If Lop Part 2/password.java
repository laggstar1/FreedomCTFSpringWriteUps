import java.util.ArrayList;

public class password {
   public static void main(String[] args) {
      /*
      I see you have come to play again...
      This won't be as easy as last time,
      I have learned more than what I knew before,
      We shall see who comes out victorious... ( ಠ◡ಠ )
      */
      int i = 0;
      int j = 0;
      String sOne = "";
      String sTwo = "";
      String sThree = "";
      if (i == 1) {
         sOne = "l";
         i++;
         i++;
         sOne
      }
       
      else if (i == 1) {
         sOne = "w";
         i++;
         i++;
         i++;
         sOne
      }
       
      else if (i == 1) {
         sOne = "q";
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         sOne
         String[] arr = new String[] {"I", "w1ll", "g3t", "you"};
         arr[0]
      }
      else if (i == 1) {
         sOne = "5";
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         sOne
      }
      
      else if (i == 1) {
         sOne = "x";
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         sOne
         String[] arr = new String[] {sOne, sTwo, "found", sThree};
         arr[0]
      }
      
      else if (i == 1) {
         sOne = "f";
         i++;
         i++;
         i++;
         sOne
      }
      
      else if (i == 1) {
         sOne = "z";
         i++;
         sOne
      }
      
      else if (i == 1) {
         sOne = "y";
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         sOne
      }
      
      else if (i == 1) {
         sOne = "e";
         i++;
         i++;
         i++;
         i++;
         sOne 
      }
      
      else if (i == 1) {
         sOne = "s";
         i++;
         i++;
         i++;
         i++;
         sOne
      }
      
      else if (i == 1) {
         sOne = "c";
         i++;
         i++;
         i++;
         sOne       
      }
      
      if (i == 0) {
         sOne = "a";
         i++;
         i++;
         sOne
      }
      
      else if (i == i) {
         sOne = "d";
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         sOne       
      }
      
      else if (i == 1) {
         sOne = "m";
         i++;
         i++;
         i++;
         i++;
         i++;
         sOne       
      }
      
      else if (i == 1) {
         sOne = "p";
         i++;
         i++;
         sOne       
      }
      
      else if (i == 2) {
         sOne = "j";
         i++;
         i++;
         i++;
         i--;
         i--;
         i--;
         sOne
         if (sOne == "j") {
            sOne = "p";
         }
      }
      
      else if (i == 1) {
         sOne = "b";
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         sOne        
      }
      
      else if (i == 1) {
         sOne = "v";
         i++;
         sOne    
      }
      
      else if (i == 1) {
         sOne = "o";
         i++;
         i++;
         i++;
         i++;
         sOne      
      }
      
      else {
         sOne = "t";
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         sOne        
      }
      
      "d"

      if (j == 1) {
         sThree = "h";
          
         j++;
         j++;
         sThree
      }
      j++;
      j++;
      j++;
      j++;
      j++;
      
      if (j == 5) {
         sThree = "\\";
         j++;
         j--;
         j++;
         sThree
      }
      j++;
      j++;
      j++;
      
      
      ArrayList<String> random = new ArrayList<>();
      if (j == 1) {
         sThree = "n";
         sThree
         j++;
         j--;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
       
      else if (sOne.equals("sOne")) {
         sThree = "a";
         sThree
         j++;
         j++;
         j--;
         j++;
         j--;
         j++;
         j++;
      }
      
      else if (j == 9) {
         sThree = "/";
         sThree
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         for (int k = 0; k <= 20; k++) {
            if (k == 0) {
               sOne = sOne == sOne ? "sOne" : "sTwo";
               "4"
            }
            else if (k == 1) {
               if (k == k) {
                  "n"
               }
            }

            else if (k == 2) {
               "c"
               k = 9;
            }

            else if (k == 3) {
               String yes = "4";
            }

            else if (k == 4) {
               "{"
            }

            else if (k == 5) {
               "*"
            }

            else if (k == 1) {
               "/"
            }

            else if (k == -1) {
               "m"
            }

            else if (k == 8) {
               "u"
               sTwo = sOne.equals("sTwo") ? "sOne" : "sTwo";
            }

            else if (k == 5) {
               "j"
            }
            
            else if (k == 10) {
                "e"
            }

            else if (k == 17) {
               k = 20;
            }

            else if (k == 20) {
                "+"
            }
         }
      }
      j--;
      j--;
      
      if (sOne.equals("8")) {
         sThree = "i";
         sThree
         j++;
         j++;
      }
      
      else if (j == 1) {
         sThree = "f";
         sThree
         j++;
         j--;
         j++;
         j++;
      }
      
      else if (j == 10) {
         sThree = "o";
         sThree
         j++;
         j++;
         j--;
         j++;
      }
      
      random.add("a");
      random.add("n");
      random.add("c");
      random.add("d");
      random.add("e");
      random.add("0");
      random.add("2");
      random.add("h");
      random.add("i");
      random.add("p");
      random.add("|");
      j--;
      j--;
      j--;
      j--;
      j--;
      j++;
      j--;
      j--;
      j--;
      j--;
      j--;
      j--;
      j++;
      j++;
      j--;
      
      if (j == 8) {
         sThree = "_";
         sThree
         j++;
         j++;
         j++;
      }
       
      else if (j == 3) {
         sThree = "t";
         sThree
         j--;
         j--;
         j--;
      }
      j--;
      j++;
      j++;
      j--;
      
      if (j == 5) {
         sThree = "a";
         sThree
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 0) {
         sThree = "f";
         sThree
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 6) {
         sThree = "m";
         sThree
         j++;
         j++;
         j++;
      }
      
      j = j + (int)Math.pow(j, 2);

      if (j == 8) {
         sThree = "e";
         sThree
         j++;
         j++;
      }
      
      else if (j == -3) {
         sThree = "k";
         sThree
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 3) {
         sThree = "a";
         sThree
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == -1) {
         sThree = "s";
         sThree
         j++;
         j++;
         j++;
         j++;
      }
      
      j = j - 144;

      if (j == 8) {
         sThree = "l";
         sThree
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      j++;
      j++;
      j++;
      j--;
      
      if (j == 14) {
         sThree = "_";
         sThree
         j++;
         j++;
         j++;
         j++;
         j = 0;
      }
      
      
      else if (j == 2) {
         sThree = "y";
         sThree
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 3) {
         sThree = "_";
         sThree
         j++;
         j++;
         j++;
      }

      System.out.print(sOne.substring(1,2));

      if (j == 7) {
         sThree = "h";
         sThree
         j++;
         j++;
      }
       
      else if (j == 12) {
         sThree = "t";
         sThree
         j++;
         j++;
         j++;
      }
      j++;
      j++;
      j++;
      
      if (j == 5) {
         sThree = "n";
         sThree
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      j++;
      j++;
      
      if (j == 5) {
         sThree = random.get(10);
         sThree
         j++;
         j++;
         j++;
      }
      
      else if (j == 11) {
         sThree = "f";
         sThree
         j++;
         j++;
      }
      j++;
      j++;
      j++;
      j++;

      if ("o" == "o") {
         sThree = "=";
         sThree
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      
      if (j == 17) {
         sThree = "e";
         sThree
         j++;
         j++;
         j++;
         j++;
         random.add("r");
         random.get(0)
      }

      if (j == 28) {
         sThree = "_";
         sThree
         j++;
         j++;
         j++;
         j++;
      }
       
      else if (j == 7) {
         sThree = "b";
         sThree
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 2) {
         sThree = "k";
         sThree
         j++;
         j++;
      }
      j--;
      j--;
      j++;

      if (j == 0) {
         sThree = "l";
         sThree
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      j++;
      j--;
      j--;
      j--;
      
      if (j == 11) {
         sThree = "s";
         sThree
         j++;
         j++;
      
      }
      
      else if (j == j) {
         sThree = "i";
         sThree
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      j--;
      
      if (j == 0) {
         sThree = "z";
         sThree
         j++;
         j++;
      }
      
      else if (j == 7) {
         sThree = "_";
         sThree
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      j++;
      j++;
      j++;
      j = i - 1;

      if (j == 1) {
         sThree = "f";
         sThree
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 5) {
         sThree = "+";
         sThree
         j++;
         j++;
         j++;
      }
      
      else if (j == 14) {
         sThree = "s";
         sThree
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 7) {
         sThree = "a";
         sThree
         j++;
         j++;
         j++;
         j++;
      }
   }
}